<?php
include "koneksi.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title>Testing</title>
</head>
<body>
	<form method="POST" action="plogin.php">
		<input type="text" name="username">
		<input type="password" name="password">
		<input type="submit" name="submit" value="kirim">
	</form>

</body>
</html>