INSERT INTO ds_penyakit(kode,nama,kett)
VALUES
('P1','Stadium 1','selow'),
('P2','Stadium 2','bray'),
('P3','Stadium 3','yow');