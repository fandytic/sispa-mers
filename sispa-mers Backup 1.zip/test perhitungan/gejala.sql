INSERT INTO ds_gejala(kode,nama)
VALUES
('G01','Batuk kering'),
('G02','Batuk berdahak'),
('G03','Merasakan flu'),
('G04','Merasakan flu berat'),
('G05','Tenggorokan terasa sakit'),
('G06','Tenggorokan terasa ada yang nyangkut'),
('G07','Terasa gatal-gatal pada tenggorokan'),
('G08','Kepala terasa sakit'),
('G09','Dada terasa sesak'),
('G10','2 minggu sebelum sakit pernah melaksanakan haji atau umroh ke timur tengah'),
('G11','Susah menarik nafas panjang'),
('G12','Denyut jantung yang dirasakan agak cepat berdetak'),
('G13','Pada siang hari badan terasa sakit-sakit'),
('G14','Demam yang dirasakan naik turun'),
('G15','Demam'),
('G16','Demam tinggi ( > 39º )'),
('G17','Pada saat malam hari badan terasa panas dan siang terasa dingin');