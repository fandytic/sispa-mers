<!-- ============================================================== -->
        <!-- footer -->
        <!-- ============================================================== -->
        <footer class="footer text-center">
            All Rights Reserved by Xtreme Admin. Designed and Developed by <a href="https://wrappixel.com">WrapPixel</a>.
        </footer>
        <!-- ============================================================== -->
        <!-- End footer -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Page wrapper  -->
    <!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Wrapper -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- All Jquery -->
<!-- ============================================================== -->
<script src="../assetsA/assets/libs/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap tether Core JavaScript -->
<script src="../assetsA/assets/libs/popper.js/dist/umd/popper.min.js"></script>
<script src="../assetsA/assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="../assetsA/dist/js/app-style-switcher.js"></script>
<!--Wave Effects -->
<script src="../assetsA/dist/js/waves.js"></script>
<!--Menu sidebar -->
<script src="../assetsA/dist/js/sidebarmenu.js"></script>
<!--Custom JavaScript -->
<script src="../assetsA/dist/js/custom.js"></script>


<script src="../assetsA/assets/libs/data-table/datatables.min.js"></script>
<script src="../assetsA/assets/libs/data-table/dataTables.bootstrap.min.js"></script>
<script src="../assetsA/assets/libs/data-table/dataTables.buttons.min.js"></script>
<script src="../assetsA/assets/libs/data-table/buttons.bootstrap.min.js"></script>
<script src="../assetsA/assets/libs/data-table/jszip.min.js"></script>
<script src="../assetsA/assets/libs/data-table/pdfmake.min.js"></script>
<script src="../assetsA/assets/libs/data-table/vfs_fonts.js"></script>
<script src="../assetsA/assets/libs/data-table/buttons.html5.min.js"></script>
<script src="../assetsA/assets/libs/data-table/buttons.print.min.js"></script>
<script src="../assetsA/assets/libs/data-table/buttons.colVis.min.js"></script>
<script src="../assetsA/assets/libs/data-table/datatables-init.js"></script>


</body>

</html>
